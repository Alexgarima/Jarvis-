import React, { useState } from 'react';
import { JarvisSettings, VoiceProfile } from '../types/jarvis';
import { voiceManager } from '../modules/VoiceManager';
import { soundEffects } from '../modules/SoundEffects';
import {
  X,
  Volume2,
  Sliders,
  Plus,
  Play,
  Trash2,
  User,
  ShieldCheck,
  Languages,
  Check,
  Radio,
} from 'lucide-react';

interface SettingsModalProps {
  settings: JarvisSettings;
  onUpdateSettings: (newSettings: JarvisSettings) => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onUpdateSettings,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'voice' | 'accessibility' | 'user'>('voice');
  const [showAddVoice, setShowAddVoice] = useState(false);
  const [newVoiceName, setNewVoiceName] = useState('');
  const [newVoicePitch, setNewVoicePitch] = useState(1.0);
  const [newVoiceRate, setNewVoiceRate] = useState(1.0);
  const [newVoiceType, setNewVoiceType] = useState<'custom' | 'mohit' | 'jarvis'>('custom');
  const [previewingId, setPreviewingId] = useState<string | null>(null);

  const allVoices = voiceManager.getAllProfiles();

  const handleSelectVoice = (voiceId: string) => {
    soundEffects.play('click');
    voiceManager.setVoiceProfile(voiceId);
    onUpdateSettings({
      ...settings,
      selectedVoiceId: voiceId,
    });
  };

  const handlePreviewVoice = async (voice: VoiceProfile) => {
    setPreviewingId(voice.id);
    soundEffects.play('click');
    await voiceManager.previewVoice(voice);
    setPreviewingId(null);
  };

  const handleSaveCustomVoice = () => {
    if (!newVoiceName.trim()) return;
    const added = voiceManager.addCustomVoice({
      name: newVoiceName.trim(),
      description: 'User-configured custom synthetic voice persona',
      type: newVoiceType,
      pitch: newVoicePitch,
      rate: newVoiceRate,
      volume: 1.0,
      lang: 'en-IN',
    });

    onUpdateSettings({
      ...settings,
      selectedVoiceId: added.id,
      customVoices: [...settings.customVoices, added],
    });

    setShowAddVoice(false);
    setNewVoiceName('');
    soundEffects.play('complete');
  };

  const handleDeleteVoice = (id: string) => {
    soundEffects.play('click');
    voiceManager.deleteCustomVoice(id);
    onUpdateSettings({
      ...settings,
      selectedVoiceId:
        settings.selectedVoiceId === id ? 'jarvis-default' : settings.selectedVoiceId,
      customVoices: settings.customVoices.filter((v) => v.id !== id),
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in font-mono select-none">
      <div className="w-full max-w-2xl bg-slate-950 border border-cyan-800/80 rounded-2xl shadow-[0_0_50px_rgba(6,182,212,0.25)] flex flex-col overflow-hidden max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-cyan-900/60 bg-gradient-to-r from-slate-900 via-cyan-950/40 to-slate-900 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full overflow-hidden border border-cyan-400/60 shadow-[0_0_10px_rgba(6,182,212,0.4)]">
              <img
                src="/jarvis-logo.jpg"
                alt="JARVIS Logo"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <span className="font-['Orbitron'] font-bold text-base tracking-wider text-white block">
                JARVIS CONTROL MATRIX
              </span>
              <span className="text-[10px] text-cyan-400 font-mono block">Personal AI Subsystem Settings</span>
            </div>
          </div>
          <button
            onClick={() => {
              soundEffects.play('click');
              onClose();
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-cyan-950 bg-slate-950/80 px-6 pt-2 gap-2 text-xs">
          <button
            onClick={() => {
              soundEffects.play('click');
              setActiveTab('voice');
            }}
            className={`pb-2.5 px-3 font-semibold transition-all border-b-2 cursor-pointer ${
              activeTab === 'voice'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Voice Synthesizer (VoiceManager)
          </button>
          <button
            onClick={() => {
              soundEffects.play('click');
              setActiveTab('accessibility');
            }}
            className={`pb-2.5 px-3 font-semibold transition-all border-b-2 cursor-pointer ${
              activeTab === 'accessibility'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Accessibility & Automation
          </button>
          <button
            onClick={() => {
              soundEffects.play('click');
              setActiveTab('user');
            }}
            className={`pb-2.5 px-3 font-semibold transition-all border-b-2 cursor-pointer ${
              activeTab === 'user'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            User Persona & Device
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">
          {activeTab === 'voice' && (
            <div className="space-y-6">
              {/* Voice Profiles List */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
                      Voice Persona Catalog
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      Modular neural voice engine powered by VoiceManager class
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      soundEffects.play('click');
                      setShowAddVoice(!showAddVoice);
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-950 border border-cyan-700/60 text-cyan-300 hover:bg-cyan-900 transition-colors cursor-pointer text-xs font-semibold"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Custom Voice</span>
                  </button>
                </div>

                {/* Add Custom Voice Drawer */}
                {showAddVoice && (
                  <div className="mb-4 p-4 rounded-xl bg-slate-900 border border-cyan-800/60 space-y-3">
                    <span className="font-bold text-cyan-300 text-xs uppercase block">
                      Create New Custom Voice Persona
                    </span>
                    <div className="space-y-1">
                      <label className="text-slate-400 text-[11px]">Voice Persona Name:</label>
                      <input
                        type="text"
                        placeholder="e.g. Mohit Alternate, Friday Tactical"
                        value={newVoiceName}
                        onChange={(e) => setNewVoiceName(e.target.value)}
                        className="w-full bg-slate-950 border border-cyan-900 rounded p-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                          <span>Pitch Modulation:</span>
                          <span className="text-cyan-300">{newVoicePitch}x</span>
                        </div>
                        <input
                          type="range"
                          min="0.5"
                          max="1.5"
                          step="0.05"
                          value={newVoicePitch}
                          onChange={(e) => setNewVoicePitch(parseFloat(e.target.value))}
                          className="w-full accent-cyan-400"
                        />
                      </div>
                      <div>
                        <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                          <span>Speed / Rate:</span>
                          <span className="text-cyan-300">{newVoiceRate}x</span>
                        </div>
                        <input
                          type="range"
                          min="0.6"
                          max="1.6"
                          step="0.05"
                          value={newVoiceRate}
                          onChange={(e) => setNewVoiceRate(parseFloat(e.target.value))}
                          className="w-full accent-cyan-400"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-2">
                      <button
                        onClick={() => setShowAddVoice(false)}
                        className="px-3 py-1.5 rounded text-slate-400 hover:text-white"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={handleSaveCustomVoice}
                        className="px-4 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-bold"
                      >
                        Save Voice Profile
                      </button>
                    </div>
                  </div>
                )}

                {/* Profiles Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {allVoices.map((voice) => {
                    const isSelected = settings.selectedVoiceId === voice.id;
                    const isPreviewing = previewingId === voice.id;

                    return (
                      <div
                        key={voice.id}
                        onClick={() => handleSelectVoice(voice.id)}
                        className={`p-3.5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                          isSelected
                            ? 'bg-cyan-950/80 border-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.2)]'
                            : 'bg-slate-900/70 border-slate-800 hover:border-cyan-900/60'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-slate-100 flex items-center gap-1.5">
                              {voice.name}
                              {voice.id === 'mohit-voice' && (
                                <span className="text-[9px] bg-emerald-950 border border-emerald-700 text-emerald-400 px-1 rounded">
                                  USER VOICE
                                </span>
                              )}
                            </span>
                            {isSelected && (
                              <Check className="w-4 h-4 text-cyan-400" />
                            )}
                          </div>
                          <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">
                            {voice.description}
                          </p>
                        </div>

                        <div className="mt-3 pt-2 border-t border-cyan-950/80 flex items-center justify-between">
                          <span className="text-[10px] text-slate-500 font-mono">
                            Pitch: {voice.pitch} · Rate: {voice.rate}
                          </span>
                          <div className="flex items-center gap-1">
                            {voice.isCustom && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteVoice(voice.id);
                                }}
                                className="p-1 rounded text-slate-400 hover:text-rose-400"
                                title="Delete Custom Voice"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handlePreviewVoice(voice);
                              }}
                              className="flex items-center gap-1 px-2 py-0.5 rounded bg-cyan-900/40 hover:bg-cyan-800 text-cyan-300 text-[10px] transition-colors"
                            >
                              <Play className="w-2.5 h-2.5 fill-current" />
                              <span>{isPreviewing ? 'Testing...' : 'Voice Preview'}</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Real-time Voice Modulation Sliders */}
              <div className="bg-slate-900/80 border border-cyan-900/50 rounded-xl p-4 space-y-4">
                <span className="font-bold text-slate-200 text-xs uppercase tracking-wider block">
                  Fine Tuning Controls
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                      <span>Voice Speed:</span>
                      <span className="text-cyan-400 font-mono">{settings.voiceSpeed}x</span>
                    </div>
                    <input
                      type="range"
                      min="0.5"
                      max="1.8"
                      step="0.05"
                      value={settings.voiceSpeed}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        voiceManager.updateVoiceParameters({ rate: val });
                        onUpdateSettings({ ...settings, voiceSpeed: val });
                      }}
                      className="w-full accent-cyan-400 cursor-pointer"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                      <span>Pitch:</span>
                      <span className="text-cyan-400 font-mono">{settings.voicePitch}x</span>
                    </div>
                    <input
                      type="range"
                      min="0.5"
                      max="1.8"
                      step="0.05"
                      value={settings.voicePitch}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        voiceManager.updateVoiceParameters({ pitch: val });
                        onUpdateSettings({ ...settings, voicePitch: val });
                      }}
                      className="w-full accent-cyan-400 cursor-pointer"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                      <span>Volume:</span>
                      <span className="text-cyan-400 font-mono">{Math.round(settings.voiceVolume * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={settings.voiceVolume}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value);
                        voiceManager.updateVoiceParameters({ volume: val });
                        onUpdateSettings({ ...settings, voiceVolume: val });
                      }}
                      className="w-full accent-cyan-400 cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'accessibility' && (
            <div className="space-y-4">
              <div className="bg-slate-900/80 border border-cyan-900/50 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-slate-200">Android Accessibility Service</h3>
                    <p className="text-[11px] text-slate-400">
                      Enables deep UI screen element traversal, click injection, and auto typing
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.accessibilityServiceEnabled}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        accessibilityServiceEnabled: e.target.checked,
                      })
                    }
                    className="w-5 h-5 accent-cyan-500 cursor-pointer"
                  />
                </div>
                <div className="text-[11px] text-slate-400 bg-slate-950 p-2.5 rounded border border-slate-800">
                  <span className="text-emerald-400 font-bold block mb-1">
                    ✓ NON-ROOT COMPLIANT
                  </span>
                  JARVIS operates strictly within standard Android APIs (Intents, Deep Links, and AccessibilityNodes). No root or dangerous system partition modifications required.
                </div>
              </div>

              <div className="bg-slate-900/80 border border-cyan-900/50 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-slate-200">Holographic Sound Effects</h3>
                    <p className="text-[11px] text-slate-400">
                      Web Audio synthesized HUD chimes and reactor beeps
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.soundEffects}
                    onChange={(e) => {
                      soundEffects.setEnabled(e.target.checked);
                      onUpdateSettings({ ...settings, soundEffects: e.target.checked });
                    }}
                    className="w-5 h-5 accent-cyan-500 cursor-pointer"
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'user' && (
            <div className="space-y-4">
              <div className="bg-slate-900/80 border border-cyan-900/50 rounded-xl p-4 space-y-3">
                <span className="font-bold text-slate-200 text-xs uppercase tracking-wider block">
                  User Identification
                </span>
                <div className="space-y-1">
                  <label className="text-slate-400 text-[11px]">Address User As:</label>
                  <input
                    type="text"
                    value={settings.userName}
                    onChange={(e) => onUpdateSettings({ ...settings, userName: e.target.value })}
                    className="w-full bg-slate-950 border border-cyan-900 rounded p-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                    placeholder="e.g. Mohit, Sir, Boss"
                  />
                </div>
              </div>

              <div className="bg-slate-900/80 border border-cyan-900/50 rounded-xl p-4 space-y-3">
                <span className="font-bold text-slate-200 text-xs uppercase tracking-wider block">
                  Language Processing Mode
                </span>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {[
                    { id: 'en-IN', label: 'Hinglish & Indian English (Recommended)' },
                    { id: 'hi-IN', label: 'Hindi (हिंदी)' },
                    { id: 'en-US', label: 'English (US)' },
                    { id: 'auto', label: 'Automatic Detection' },
                  ].map((lang) => (
                    <button
                      key={lang.id}
                      onClick={() =>
                        onUpdateSettings({ ...settings, preferredLanguage: lang.id as any })
                      }
                      className={`p-2.5 rounded border text-left cursor-pointer transition-colors ${
                        settings.preferredLanguage === lang.id
                          ? 'bg-cyan-950 border-cyan-400 text-cyan-300 font-bold'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {lang.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Developer Contact, Help & Support */}
              <div className="bg-slate-900/90 border border-cyan-700/60 rounded-xl p-4 space-y-3 shadow-lg">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-200 text-xs uppercase tracking-wider block">
                    Contact, Help & Support
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800">
                    DEVELOPER
                  </span>
                </div>
                <div className="p-3 rounded-lg bg-slate-950 border border-cyan-900/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <span className="text-[11px] text-slate-400 block">Developer Support Email:</span>
                    <a
                      href="mailto:mohitgurjar988729@gmail.com?subject=JARVIS%20AI%20Support"
                      className="text-xs font-bold text-cyan-300 hover:text-white font-mono break-all"
                    >
                      mohitgurjar988729@gmail.com
                    </a>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText('mohitgurjar988729@gmail.com');
                        soundEffects.play('confirm');
                      }}
                      className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-[11px] font-semibold text-slate-200 border border-slate-700 transition-colors cursor-pointer"
                    >
                      Copy Email
                    </button>
                    <a
                      href="mailto:mohitgurjar988729@gmail.com?subject=JARVIS%20AI%20Support"
                      className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-[11px] font-semibold text-white transition-colors cursor-pointer"
                    >
                      Email Me
                    </a>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-cyan-900/60 bg-slate-900/90 flex justify-end">
          <button
            onClick={() => {
              soundEffects.play('confirm');
              onClose();
            }}
            className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-[0_0_15px_rgba(6,182,212,0.3)] transition-all cursor-pointer"
          >
            Apply & Synchronize
          </button>
        </div>
      </div>
    </div>
  );
};
