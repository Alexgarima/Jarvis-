import { speechManager } from './SpeechManager';
import { soundEffects } from './SoundEffects';

type BackgroundStateListener = (state: {
  isWakeLockActive: boolean;
  isBackgroundListening: boolean;
  isStandbyActive: boolean;
}) => void;

class BackgroundWakeManager {
  private wakeLockSentinel: any = null;
  private isBackgroundListening: boolean = false;
  private isStandbyActive: boolean = false;
  private keepAliveAudioCtx: AudioContext | null = null;
  private keepAliveInterval: number | null = null;
  private listeners: Set<BackgroundStateListener> = new Set();
  private onCommandDetectedCallback: ((text: string) => void) | null = null;

  constructor() {
    if (typeof document !== 'undefined') {
      document.addEventListener('visibilitychange', async () => {
        if (document.visibilityState === 'visible' && this.isWakeLockActive()) {
          // Re-acquire wake lock if re-focused
          await this.requestWakeLock();
        }
      });
    }
  }

  public subscribe(cb: BackgroundStateListener): () => void {
    this.listeners.add(cb);
    cb(this.getState());
    return () => {
      this.listeners.delete(cb);
    };
  }

  private notify() {
    const s = this.getState();
    this.listeners.forEach((l) => l(s));
  }

  public getState() {
    return {
      isWakeLockActive: !!this.wakeLockSentinel,
      isBackgroundListening: this.isBackgroundListening,
      isStandbyActive: this.isStandbyActive,
    };
  }

  public isWakeLockActive(): boolean {
    return !!this.wakeLockSentinel;
  }

  public async requestWakeLock(): Promise<boolean> {
    if (typeof navigator !== 'undefined' && 'wakeLock' in navigator) {
      try {
        this.wakeLockSentinel = await (navigator as any).wakeLock.request('screen');
        this.wakeLockSentinel.addEventListener('release', () => {
          this.wakeLockSentinel = null;
          this.notify();
        });
        this.startKeepAliveAudio();
        this.notify();
        return true;
      } catch (err) {
        console.warn('Screen WakeLock error:', err);
        return false;
      }
    }
    return false;
  }

  public releaseWakeLock() {
    if (this.wakeLockSentinel) {
      try {
        this.wakeLockSentinel.release();
      } catch {
        // Safe catch
      }
      this.wakeLockSentinel = null;
    }
    this.stopKeepAliveAudio();
    this.notify();
  }

  public toggleWakeLock(): Promise<boolean> {
    if (this.wakeLockSentinel) {
      this.releaseWakeLock();
      return Promise.resolve(false);
    }
    return this.requestWakeLock();
  }

  public setStandbyActive(active: boolean) {
    this.isStandbyActive = active;
    if (active) {
      this.requestWakeLock();
      this.startBackgroundListening();
    }
    this.notify();
  }

  public startBackgroundListening(onCommand?: (text: string) => void) {
    if (onCommand) {
      this.onCommandDetectedCallback = onCommand;
    }
    this.isBackgroundListening = true;
    this.startKeepAliveAudio();
    this.runContinuousListeningLoop();
    this.notify();
  }

  public stopBackgroundListening() {
    this.isBackgroundListening = false;
    speechManager.stopListening();
    this.notify();
  }

  private runContinuousListeningLoop() {
    if (!this.isBackgroundListening) return;

    if (!speechManager.isListening()) {
      speechManager.startListening({
        onResult: (transcript, isFinal) => {
          if (isFinal && transcript.trim()) {
            soundEffects.play('confirm');
            this.onCommandDetectedCallback?.(transcript);
          }
        },
        onStateChange: (listening) => {
          // If speech recognition ends and continuous listening is enabled, auto restart
          if (!listening && this.isBackgroundListening) {
            setTimeout(() => {
              if (this.isBackgroundListening) {
                this.runContinuousListeningLoop();
              }
            }, 600);
          }
        },
        onError: () => {
          if (this.isBackgroundListening) {
            setTimeout(() => {
              if (this.isBackgroundListening) {
                this.runContinuousListeningLoop();
              }
            }, 1000);
          }
        },
      });
    }
  }

  // Audio Keep-Alive: Plays an imperceptible silent tick every 20s to prevent mobile browser suspension
  private startKeepAliveAudio() {
    if (typeof window === 'undefined') return;
    if (!this.keepAliveAudioCtx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.keepAliveAudioCtx = new AudioCtx();
      }
    }

    if (!this.keepAliveInterval && this.keepAliveAudioCtx) {
      this.keepAliveInterval = window.setInterval(() => {
        if (!this.keepAliveAudioCtx) return;
        try {
          if (this.keepAliveAudioCtx.state === 'suspended') {
            this.keepAliveAudioCtx.resume();
          }
          const osc = this.keepAliveAudioCtx.createOscillator();
          const gain = this.keepAliveAudioCtx.createGain();
          gain.gain.value = 0.00001; // Inaudible
          osc.connect(gain);
          gain.connect(this.keepAliveAudioCtx.destination);
          osc.start();
          osc.stop(this.keepAliveAudioCtx.currentTime + 0.05);
        } catch {
          // ignore
        }
      }, 15000);
    }
  }

  private stopKeepAliveAudio() {
    if (this.keepAliveInterval) {
      clearInterval(this.keepAliveInterval);
      this.keepAliveInterval = null;
    }
  }
}

export const backgroundWakeManager = new BackgroundWakeManager();
